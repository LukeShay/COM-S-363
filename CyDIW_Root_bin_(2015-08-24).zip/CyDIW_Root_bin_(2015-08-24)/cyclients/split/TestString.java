package cyclients.split;

public class TestString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="hello";
		String b=a;
		System.out.println(b);

	}

}
