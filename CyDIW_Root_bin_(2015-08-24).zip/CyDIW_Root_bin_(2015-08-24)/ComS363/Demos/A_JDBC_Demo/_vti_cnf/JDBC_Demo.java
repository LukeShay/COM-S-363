vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Jan 2014 17:37:28 -0000
vti_extenderversion:SR|6.0.2.8161
vti_backlinkinfo:VX|Archives/Projects/02_JDBC/JDBC.htm Resources/Resources.htm
vti_author:SR|PANINI\\gadia
vti_modifiedby:SR|panini\\gadia
vti_nexttolasttimemodified:TW|23 Jan 2014 17:28:26 -0000
vti_timecreated:TR|29 Sep 2011 23:33:37 -0000
vti_syncwith_ftp.cs.iastate.edu\:21/www:TW|23 Jan 2014 13:51:42 -0000
vti_syncofs_ftp.cs.iastate.edu\:21/www:TW|23 Jan 2014 13:52:00 -0000
vti_cacheddtm:TX|23 Jan 2014 17:28:26 -0000
vti_filesize:IR|4181
