vti_encoding:SR|utf8-nl
vti_author:SR|PANINI\\gadia
vti_modifiedby:SR|PANINI\\gadia
vti_timelastmodified:TR|23 Jan 2013 22:43:56 -0000
vti_timecreated:TR|03 Sep 2011 11:51:33 -0000
vti_extenderversion:SR|6.0.2.8161
vti_backlinkinfo:VX|Resources/Resources.htm
vti_syncwith_ftp.cs.iastate.edu\:21/www:TX|03 Sep 2011 11:51:33 -0000
vti_syncofs_ftp.cs.iastate.edu\:21/www:TW|23 Jan 2013 06:00:00 -0000
vti_nexttolasttimemodified:TR|23 Jan 2013 20:57:44 -0000
vti_cacheddtm:TX|03 Sep 2011 11:51:33 -0000
vti_filesize:IR|513
